// $('.reviews-flex').bxSlider({
//     mode: 'fade',
//     controls: false,
//     randomStart: true,
// });