$('.carousel').bxSlider({
    mode: 'fade',
    controls: false,
    randomStart: true,

});